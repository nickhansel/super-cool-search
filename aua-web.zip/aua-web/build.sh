#!/bin/bash
version=""
project=""
name=aua-web

docker build -t gcr.io/$project/$name:$version .
docker push gcr.io/$project/$name:$version
