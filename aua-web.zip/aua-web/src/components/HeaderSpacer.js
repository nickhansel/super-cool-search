
import './Header.css';

function HeaderSpacer() {
  return (
    <div className="HeaderSpacer">
    </div>
  );
}

export default HeaderSpacer;
