import './SearchResult.css';

import { useState, useEffect, useLayoutEffect, useRef } from 'react';
import grad from '../utils/grad';

import Bubble from './Bubble';
import { DateTime } from 'luxon';

const boldify = (text, highlight) => {
  if (highlight && highlight.end) {
    return (<span>
      {text.substring(0, highlight.start)}
      <span className="SearchResultHighlight">{text.substring(highlight.start, highlight.end)}</span>
      {text.substring(highlight.end)}
    </span>);
  }
  return text;
}

function Post({ post, children }) {
  const [expanded, setExpanded] = useState(false);
  const previewLength = 140;
  const condensedText = post?.selftext?.length <= previewLength ? post?.selftext : `${(post.selftext || "").substring(0, previewLength)}... `;

  return (
      <a className="Post"  href={post?.url}>
        <Bubble className="PostAuthorBubble" small seed={post?.author?.id} symbol={"❔"}/>
        <div className="PostContent">
          <div className="PostTitle">{post?.title}</div>
          {post?.selftext ? 
            <div className={("PostText")}>
              {expanded ? post?.selftext : condensedText}
              {!expanded && post?.selftext?.length > previewLength ? <span className="PostExpandButton" onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                setExpanded(true);
              }}>expand</span> : ""}
            </div>
            : ""}
          <div className="PostInfo">
            {post?.subreddit?.displayName ? <div className="PostSubreddit">{post?.subreddit?.displayName}</div> : ""}
            {post?.score ? <div className="PostUpvotes"><span className="EmojiIcon">⬆️ </span>{post?.score}</div> : ""}
            {post?.created ? <div className="PostDate"><span className="EmojiIcon">🕓 </span>{DateTime.fromISO(post?.created).toLocaleString()}</div> : ""}
            {post?.author?.id ? <div className="PostAuthor"><span className="EmojiIcon">🙇 </span>{post?.author?.id}</div> : ""}
          </div>
        {children}
        </div>
      </a>
  );
}

function orderTree(id, threadMap, childrenMap) {
  const children = childrenMap[id];
  if (!children || children?.length === 0) {
    return {id, orderedChildren: [], score: threadMap[id]?.compositeScore || 0};
  }
  const childrensOrderings = children.map((child) => {
    return orderTree(child, threadMap, childrenMap);
  });
  const orderedChildren = childrensOrderings.sort((a, b) => b.score - a.score);
  return {id, orderedChildren, score: Math.max(orderedChildren[0].score, threadMap[id]?.compositeScore || 0)}
}


function PostComment({ thread, id, children }) {
  const [expanded, setExpanded] = useState(false);
  const isMainComment = thread?.comment?.id === id;
  const comment = isMainComment ? thread?.comment : thread?.comment?.parentComment;
  const body = comment?.body;
  
  const previewLength = 140;

  let previewStart = 0;
  
  if (isMainComment) {
    const midpoint = thread?.answerHighlight?.start + thread?.answerHighlight?.end;
    previewStart = Math.round(Math.max(
      0,
      midpoint / 2 - Math.max(previewLength / 2, previewLength - (body?.length - midpoint))
    ));
  }

  let condensedText = comment?.body?.substring(previewStart, previewStart + previewLength);

  let condensedSnippet = (
    <span>
      {isMainComment ? 
        boldify(condensedText, {start: thread?.answerHighlight?.start - previewStart, end: thread?.answerHighlight?.end - previewStart})
        : condensedText
      }
    </span>
  );

  const expandedSnippet = (
    <span>
      {isMainComment ? 
        boldify(body, thread?.answerHighlight)
        : body
      }
    </span>
  );

  const commentText = (
    <div>
      {!expanded && previewStart > 0 ? <span>...</span> : ""}
      {expanded ? expandedSnippet : condensedSnippet}
      {!expanded && previewStart + previewLength < body?.length ? <span>... </span> : ""}
    </div>
  );

  return (
    <a className="PostComment"  href={comment?.url}>
        <Bubble className="CommentAuthorBubble" small seed={comment?.author?.id} symbol={"🙇"}/>
        <div className="CommentContent">
          {comment?.body ? 
            <div className={("CommentBody")}>
              {commentText}
              
              {/* expand button */}
              {!expanded && comment?.body?.length > previewLength ? <span className="CommentExpandButton" onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                setExpanded(true);
              }}>expand</span> : ""}
            </div>
            : ""}
          <div className="CommentInfo">
            {comment?.score ? <div className="CommentUpvotes"><span className="EmojiIcon">⬆️ </span>{comment?.score}</div> : ""}
            {comment?.created ? <div className="CommentDate"><span className="EmojiIcon">🕓 </span>{DateTime.fromISO(comment?.created).toLocaleString()}</div> : ""}
            {comment?.author?.id ? <div className="CommentAuthor"><span className="EmojiIcon">🙇 </span>{comment?.author?.id}</div> : ""}
          </div>
          {children?.length ?
            <div className="PostThreads">
              {children}
            </div>
            : ""
          }
        </div>
      </a>
  )
}

function CommentSubTree({ tree, threadMap }) {
  if (tree.id === "post") {
    return (
      <div className="PostThreads">
        {tree?.orderedChildren.map((child) => <CommentSubTree key={child.id} tree={child} threadMap={threadMap}/>)}
      </div>
    )
  }
  return (
    <PostComment key={tree.id} thread={threadMap[tree.id]} id={tree.id}>
      {tree?.orderedChildren.map((child) => <CommentSubTree key={child.id} tree={child} threadMap={threadMap}/>)}
    </PostComment>
  )
}

function PostThreads({ threads }) {
  // Here we manage the comment parent-child relationships and sort the tree based on the highest leaf / branch compositeScore
  const childrenMap = threads?.reduce((obj, thread) => {
    const c = thread.comment;
    const p = c?.parentComment;
    if (p) {
      if (p.id in obj) {
        obj[p.id].push(c.id);
      } else {
        obj[p.id] = [c.id];
      }
    } else {
      if ("post" in obj) {
        obj["post"].push(c.id);
      } else {
        obj["post"] = [c.id];
      }
    }
    // const r = c.opResponse;
    // if (r) {
    //   if (c.id in obj) {
    //     obj[c.id].push(r);
    //   } else {
    //     obj[c.id] = [r];
    //   }
    // }
    return obj;
  }, {});

  const threadMap = threads?.reduce((obj, thread) => {
    const c = thread.comment;
    const p = c?.parentComment;

    obj[c?.id] = thread;
    if (p && !(p?.id in obj)) {
      obj[p?.id] = thread;
    }
    return obj;
  }, {});

  const orderedTree = orderTree("post", threadMap, childrenMap)
  return (
    <CommentSubTree tree={orderedTree} threadMap={threadMap}/>
  );
}

function SearchResult({ post, threads }) {
  return (
      <div className="SearchResult">
        <Post post={post}>
          <PostThreads threads={threads}/>
        </Post>
      </div>
  );
}

export default SearchResult;
