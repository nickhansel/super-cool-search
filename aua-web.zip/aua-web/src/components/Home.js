import './Home.css';

import react, { useEffect } from 'react';
import { useState } from 'react';
import {
  Outlet
} from "react-router-dom";
import Header from './Header';
import SideBar from './SideBar';

function Home() {
  const [sideBarSections, setSideBarSections] = useState([
    {
      id: "explore-more",
      title: "Explore More",
      buttons: [],
      items: []
    },
    {
      id: "dig-deeper",
      title: "Dig Deeper",
      buttons: [],
      items: []
    }
  ]);

  const updateSideBarSection = (section_id, section) => {
    const newSections = sideBarSections.map((oldSection) => ((section_id === oldSection.id) ? section : oldSection));
    setSideBarSections(newSections);
  }


  return (
    <div className="Home">
      <Header />
      <SideBar sections={sideBarSections}/>
      <Outlet context={[sideBarSections, setSideBarSections]}/>
    </div>
  );
}

export default Home;
