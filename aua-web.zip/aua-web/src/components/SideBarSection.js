import { Link } from 'react-router-dom';

import './SideBarSection.css';
import Bubble from './Bubble';

function SideBarItem({ id, url, route, title, image, hue, symbol }) {
  return (
    <div className="SideBarItem">
      {url ?
        <a href={url} className="SideBarItemLeft">
          <Bubble
            image={image}
            hue={hue}
            seed={id}
            symbol={(symbol) ? symbol : ""}
          />
          <div className="SideBarItemTitle">
            {title}
          </div>
        </a>
        :
        <Link to={`/${route}/${id}`} className="SideBarItemLeft">
          <Bubble
            image={image}
            hue={hue}
            seed={id}
            symbol={(symbol) ? symbol : ""}
          />
          <div className="SideBarItemTitle">
            {title}
          </div>
        </Link>
      }
    </div>
  );
}

function SideBarSection({ title, route, items, buttons }) {
  return (
    <div className="SideBarSection">
      <div className="SideBarHeading">
        <div className="SideBarHeading-title">
          { title }
        </div>
        <div className="SideBarHeadingButtons">
          {buttons.map(({ text, to }) => (
            <Link to={to}>
              <div className="SideBarHeadingButton">
                {text}
              </div>
            </Link>
          ))}
        </div>
      </div>
      <div className="SideBarItems">
        {items?.map((item) => <SideBarItem
          key={item.id}
          id={item.id}
          url={item.url}
          route={route}
          title={item.title}
          image={item.bubbleImage}
          hue={item.hue}
          symbol={item.emoji}
          />)
        }
      </div>
      <div className="SideBarFooter">
        <Link to='/feeds'>
          <div className="SideBarSeeAll">
            See all
          </div>
        </Link>
      </div>
    </div>
  );
}

export default SideBarSection;
