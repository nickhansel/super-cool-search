import './App.css';

import react from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";


import Home from './components/Home';

import SearchResults from './pages/SearchResults';

class App extends react.Component {

  constructor(props) {
    super(props);

    this.state = {
      userId: "1"
    };
  }

  render() {
    const { userId } = this.state;

    return (
      <Router>
        <Routes>
          <Route path="/" element={<Home/>}>
            <Route path="search">
              <Route path=":query" element={<SearchResults /> } />
            </Route>
            <Route index element={<SearchResults/>} />
          </Route>
        </Routes>
      </Router>
    );
  }

}

export default App;
