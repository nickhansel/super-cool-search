import { API_URL } from './api';

function search(query) {
  return fetch(`${API_URL}/search/${query}`,
        {
          method: 'GET',
          headers: {
            "Content-Type": "application/json"
          },
        }
      )
      .then(res => res.json())
      .then(
        (data) => {
          console.log('data', data);
          return data?.feed || {};
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          console.log(error);
          return {};
        }
      );
}

export default search;
