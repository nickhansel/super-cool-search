import { useState, useEffect } from 'react';
import { useOutletContext, useParams } from 'react-router-dom';

import './SearchResults.css';

import SearchResult from '../components/SearchResult';
import Spinner from '../components/ui/Spinner'

import search from '../operations/search';

function SearchResults() {
  let { query } = useParams();
  const [sideBarSections, setSideBarSections] = useOutletContext();

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const defaultQuery = "7 day Korea itinerary";

  const handleSideBar = (data) => {
    const subreddits = data?.subreddits?.map(({id, displayName}) => ({
      id,
      title: displayName,
      url: `https://www.reddit.com/r/${displayName}`,
      bubbleImage: "",
      hue: "",
      emoji: "",
    }));

    setSideBarSections([
      {
        id: "explore-more",
        title: "Explore More",
        buttons: [],
        items: subreddits
      },
    ]);
  }

  useEffect(() => {
    setLoading(true);
    search(query ? query : defaultQuery).then((data) => {
      console.log(data);
      setResults(data?.items || []);

      handleSideBar(data);
      setLoading(false)
    });
  }, [query, setSideBarSections]);

  return (
    <div className="SearchResults ContentArea">
      <h2>"{query ? query : defaultQuery}"</h2>
      {loading ? <div className="SpinnerBox">
          <Spinner/>
        </div> : results?.map((result) => (
        <SearchResult
          key={result?.post?.id}
          post={result?.post}
          threads={result?.threads}
        />
      ))}
    </div>
  );
}

export default SearchResults;
